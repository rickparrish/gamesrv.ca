+--------------------------------------------------------------------------+
|         T r a d e   W a r s   2 0 0 2   U p d a t e    F o r m           |
|                                                                          |
|      We need the info you originally registered with AND your current    |
|      address so we can find your original registration to verify your    |
|      status for the free upgrade. Please take note that if you have a    |
|      version 2x code already, you do NOT need a new code for v3.         |
|                                                                          |
|  Original Registration Info            Current/Mailing address           |
|                                    ||                                    |
|                                    ||                                    |
| Name _____________________________ || __________________________________ |
|                                    ||                                    |
| Addr _____________________________ || __________________________________ |
|                                    ||                                    |
| CityST&ZIP________________________ || __________________________________ |
|                                    ||                                    |
| Home Phone________________________ || __________________________________ |
|                                    ||                                    |
| BBS Phone ________________________    __________________________________ |
|                                                                          |
|                                                                          |
|  BBS Name ______________________________________________________________ |
|           (Registration will be keyed to this)                           |
|                                                                          |
|  BBS Sysop Name ________________________________________________________ |
|           (will also appear in the game)                                 |
|Check                                                                     |
| One  If you registered Trade Wars 2002 before January 1st, 1994 then     |
| ____ there is no charge to upgrade to version 3.x   Simply  complete     |
|  $0  this form and mail or fax it to us.                                 |
|                                                                          |
| ____ If you registered 1.xx after January 1st, 1994, then there is       |
| $10  a ten dollar ($10) charge to upgrade.  US FUNDS ONLY!               |
|                                                                          |
| ____ To upgrade to the Trade Wars 2002 Gold add-on, the charge is        |
| $25  twenty five dollars ($25).  US FUNDS ONLY!                          |
|      (The Gold add-on requires a registered TW2002 ver. 3.06)            |
|                                                                          |
|      You can mail this form to:      Martech Software, Inc.              |                          
|                                      C/o TW2002 Update Offer             |
|                                      P.O. Box 1358                       |
|                                      Lawrence, KS  66044                 |
|                                                                          |
|      Please allow 3-4 weeks for delivery.                                |
|                                                                          |
|      ** VISA, MasterCard and American Express Accepted!**  Send this     |
|      form with the information below to  the address  shown above or     |
|      send it to our FAX number at (785) 842-7818                         |
|                                                                          |
|      Card Number _________________________________________________       |
|                                                                          |
|      VISA ___  MasterCard ___ AmExp ___  Expire Date _____________       |
|                                                                          |
|      Name (as it appears on the card)_____________________________       |
|                                                                          |
|      Signature ___________________________________________________       |
|3.09                                                                      |
+--------------------------------------------------------------------------+

