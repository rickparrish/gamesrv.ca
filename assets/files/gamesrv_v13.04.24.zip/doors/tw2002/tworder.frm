+--------------------------------------------------------------------------+
|          T r a d e   W a r s   2 0 0 2   O r d e r   F o r m             |
|                                                                          |
|                                                                          |
|      Complete the blanks and mail to the author's address below.         |
|                                                                          |
|                                                                          |
|      Real Name ___________________________________________________       |
|                                                                          |
|                                                                          |
|      Street Address ______________________________________________       |
|                                                                          |
|                                                                          |
|      City, State & ZIP ___________________________________________       |
|                                                                          |
|                                                                          |
|      Voice or Home Phone (_____)__________________                       |
|                                                                          |
|                                                                          |
|      BBS or Data Phone   (_____)__________________                       |
|                                                                          |
|                                                                          |
|      BBS Name ____________________________________________________       |
|      (Registration will be keyed to this)                                |
|                                                                          |
|                                                                          |
|      BBS Sysop Name ______________________________________________       |
|      (will also appear in the game)                                      |
| Check                                                                    |
|  One    -=-=-=-=-=-   Registration Cost for TW2002  -=-=-=-=-=-=-        |
| ____ Trade Wars 2002  Std edition                             $25.00     |
| ____ Trade Wars 2002 Gold edition (includes Std registration) $45.00     |
|                                                                          |
|           (If you live in Kansas you must add 6.5% sales tax!)           |
|         -=-=-=-=- All funds must be drawn on US Banks!! -=-=-=-=-        |
|      Print and mail this form with check or money order only to:         |
|                                                                          |
|      Martech Software, Inc.                                              |
|      P.O. Box 1358                                                       |
|      Lawrence, Kansas  66044                                             |
|                                                                          |
|      Please allow 3-4 weeks for delivery.                                |
|      (Check the TWSYSOP.DOC for info about Online Ordering!)             |
|                                                                          |
|      ** VISA, MasterCard and American Express Accepted!**  Send this     |
|      form with the information below to  the address  shown above or     |
|      send it to our FAX number at (785) 842-7818                         |
|                                                                          |
|                                                                          |
|      Card Number _________________________________________________       |
|                                                                          |
|      VISA ___  MasterCard ___ AmExp ___  Expire Date _____________       |
|                                                                          |
|      Name (as it appears on the card)_____________________________       |
|                                                                          |
|      Signature ___________________________________________________       |
|3.09                                                                      |
+--------------------------------------------------------------------------+

