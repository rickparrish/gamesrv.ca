                       BUG REPORT/COMMENT/SUGGESTION FORM
                       ----------------------------------
                              PLANETS: TEOS                     

VERSION NUMBER: 2.02

1.  BUG REPORT:

    a.  While doing the following :______________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
________________________________________________________________________.

    b.  I experienced the following problem:_____________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
________________________________________________________________________.

2.  SUGGESTIONS:

    a.  I would like to see the following additions to the program:______
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
________________________________________________________________________.

    b.  I would like to see the following changes to the program:________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
________________________________________________________________________.

3.  COMMENTS ON THE GAME: _______________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________
_________________________________________________________________________

4.  INFORMATION ABOUT YOUR SYSTEM/SURVEY:
    
    a.  BBS Software you are using:______________________________________
    b.  BBS Software version number:________________
    c.  I am running (circle one):  Single Node   Multi-node   LAN-Multi-Line
    d.  I use the following multi-tasker program:________________________
    e.  Do you have share loaded (Circle one):     Yes    No
    f.  Do you have ANSI.SYS loaded (Circle one):  Yes    No
    g.  What type computer processor are you using:
          (Circle One):   XT    286    386SX     386     486     PENTIUM
    h.  Operating system and Version you are using:______________________
    i.  What is the speed of your computer processor: _________mhz
    j.  How much RAM does your system have:___________________
    k.  Do you use a fossil (Circle one):          Yes    No
    l.  If the answer was yes what type fossil:__________________________
    m.  Do you lock your ports (Circle one):       Yes    No
    n.  If the answer was yes at what speed:_____________________________
    o.  What is the highest baud rate you support:_______________________

5.  LAST NAME:______________________ FIRST NAME:_________________________
    ADDRESS:_____________________________________________________________
    VOICE PHONE:_________________________________________________________
    BEST TIME TO CALL ME:________________________________________________
    YOUR EMAIL ADDRESS:__________________________________________________

6.  THANK YOU for taking the time to fill this form out and send it to me.
    
    You can either mail it to me at:
                        Michael Preslar
                        207 Pearl Str, Apt F
                        Wayne, NE, 68787

    OR EMAIL it to me: e_maus@covingtononline.com

    I can also be found in Fidonet's doorgames echo, as well as
    the lord echo.

    If you left your voice number, I'm assuming you won't be angry if I call
    you for more information/clarification. <G>  
    
              Thank you for your BUG REPORT/SUGGESTION/COMMENT!
