Nothing
Dagger
Rambo Knife
Short Sword
Whip
Yataghan
Heavy Club
Mace
Long Sword
Short Spear
French Epee
Wooden Axe
Copper Axe
Trident
16th Century Rapier
Bronze Axe
Bastard Sword
Poisoned Iron Thorns
Military Flail
Giant Mace
Short Cutlass
Curving Scimitar
Thrusting Scimitar
Morning Star
Twin Axes
Broad Sword
Stick of the Old One
Damocles Sword
Javelin
Neptune's Trident
Golden Scimitar
Iron Axe
Assyrian Sword
Long Iron Axe
War Axe
Slashing Cavalry Sword
Evil's Ebony Javelin
Long Range Morning Star
Two-handed Sword
Heavy Steel Morning Star
Silver Dagger
Trojan Lance
Bloodsword
Black Ruby Axe
Bronze Sword
Spear Of Fear
Lost Sword of the Incas
Ripper Saw
Fearless Touch
Silver Sword
Spiked Throwing Mace
Master's Onyx Scimitar
Long Silver Sword
Fireglass Scimitar
Dual Twin Axes
Spiked Onyx Club
Sworceror's Staff
Ivory Blade
Necromancer's Arm
Master's Wodden Stick
Dreamer's Glass Dagger
Ruby-molded Yataghan
Spiked Cat Of Nine Tails
Fire Sword
Conan's Sword
King Arthur's Excalibur
Beheading Yataghan
Poisoned Silver Javelin
Whip of the Devil
Evil-forged Lance
Iron of Death
Bringer of Plagues
Bearer of Blood
Blade of Justice
Falcon's Axe
Reptilian Scimitar
Urcus' Axe
Medusa's Gaze
Widow Makers' Lance
Blade of Destiny
Iron of Blood
Tongue of Fire
Poisonous Sting
Devil's Trident
Unholy Reaper
Twin Beheaders
Brain Drainer
Fire Wall
Axe of the Fourth Rider
The Blood of Others
Soul Displacer
Cristal Blade
Beast's Incarnation
Beast's Reincarnation
Sight of Death
Eye of the Beholder
Ruby Edge Silver Dagger
Zeus' Thunder
Thor's Hammer
Eternal Death
Horn of the First Rider
Devil's Horn
Breath of Death
Satan's Book of Death
Belzebu's Hand
Khalal's Wraith
