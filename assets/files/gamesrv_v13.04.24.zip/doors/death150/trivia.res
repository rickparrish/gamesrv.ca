IN THE 1ST QUESTION, THE ANSWER IS AT 1ST '^'. IN THE 2ND QUESTION, THE ANSWER IS IN THE 2ND '^'. GO UP 4 QUESTIONS AND RESTART (SO 5TH, 9TH, 13TH ANSWER IS 1ST '^' AND 6TH, 8TH IS 2ND '^')
 Centuries ago there was a country called United States.\r What was the FLOWER of the State called RHODE ISLAND?
^Violet|^Rose|^Forget-Me-Not|^Carnation
 Centuries ago, in 1776, in a country later known as United States\r a document called DECLARATION OF INDEPENDENCE was adopted...\r Among other things, what did it mean?
^England gave up rights on the U.S.|^U.S. breaks with England and war declaration|^Intolerable acts declared unconstitutional
 Centuries ago, a country known as United States went thru a process\r called INDEPENDENCE.  What gave the U.S. its independence?
^Declaration of independence in 1776|^Severe Intolerance Acts in 1774|^The Treaty of Paris in 1783|^Battle of Bunker Hill in 1775
 Centuries ago, there was a country called Mexico.\r May 5 (Cinco de Mayo) was celebrated by this country to symbolize:
^Sell of Texas and California to U.S.A.|^Independence from Spain|s^Eparation from Central America|^Victory over France
 Many moons ago, a place called TEXAS had a battle called\r The Battle Of San Jacinto (1835).\r What was accomplished in this battle?
^Independence from Mexico|^Refusal of annexation from U.S.A.|^Approval of annexation to U.S.A.|^Slaves Liberation
 Many moons ago, the U.S.A., in a war against Mexico, conquered\r New Mexico, California, Mexico City, etc.\r What ended the war?
^Predident Taylor's death in 1850|^The treaty of Guadalupe in 1848|^Discovery of gold in California [1848]|^Oregon's division between Canada and U.S. [1846]
 Long ago, Mexico ceded California and New Mexico to U.S.A.\r How much did the U.S.A. pay?
^A> $250,000|^B> $3,000,000|^C> $15,000,000|^D> $71,000,000
 What was the main reason for the Civil War of a country known as\r United Stated of America centuries ago?
^Eli Whitney's cotton gin invention [1793]|^War against Mexico in 1848|^Formation of the Republican Party in 1854|^Ongoing Slavery [up to 1861]
 Back in time when man was not civilized enough to enter the Death\r Masters Arena, there was a war known as World War II.\r When did the war end?
^A> 1945|^B> 1937|^C> 1898|^D> 1927
 Before the collapse of the continents in the year 3042, there was a\r continent called Africa.\r What was approximately the area of Africa?
^A> 17,000,000 Square Miles|^B> 11,500,000 Square Miles|^C> 22,500,000 Square Miles|^D> 47,000,000 Square Miles
 Being as well built as you are, here is a question you are sure to\r know the answer to: What is the medical term for prolonged\r sexual intercourse without ejaculation?
^Impermeable|I^ndolent|^Karezza|^Neuritis
 Although there has never been greater men than ancient Death Masters\r long ago almost anyone was famous.  Among these so-called famous\r people, one said, "All the world's a stage."  Who said it?
^Miguel de Cervantes|^Charles Chaplin|^Adolf Hitler|^Shakespeare
 Centuries ago, before the oceans dried up and the soil could bare plants\r there was something known to mortals as TIGER BARBS.\r What are TIGER BARBS?
^Tropical fish|^Plant from the Amazons|^Hair under Tiger's chin|^Fungus found on rotten food
 Before the discovery of IQ-enhancing drugs, humans relied in one of\r their darker period of time on something called computers.\r What did the ASCII decimal number 60 represented?
Capital letter ^P|Less than sign ^<|Question mark ^?|Lowercase letter ^q
 The Death Masters Arena goes back a long time. Researchers have found\r evidence of a game called HOCKEY that evolved into our modern Arena.\r What was called THE PUCK back then?
^The act of scoring with the skates|^Masks used by the goalies|^Spherical rubber-made playing piece|S^lashing someone in the face with the stick
 Before the Continents collapsed into one in the year 3042, there\r was a country with a population of about 6 millions called\r EL SALVADOR.  Where was this country?
Next to ^Greece|Next to ^Venezuela|Next to ^Israel|Next to ^Honduras
 Although astral science has replaced now defunt mathematics, can you\r tell me what number ADDED to the SUM of the 2 numbers resulting of\r multiplying the number by 3 gives as an answer 10?
^Seven|^Three|^Five|^No such number
 Long ago, before the Inquisitor was established to inform us of events in\r the Master's Arena, people used something called NEWSPAPERS.\r The first paper was printed in China in what year?
^A> 1320|^B> c. 860|^C> 57 BD|^D> c. 1550
 Nothing is more magnificent than the eight wonder of the world: THE DEATH\r MASTERS ARENA! But can you tell me which of the other seven\r is the oldest?
^Statute of Zeus|^Hanging Babylon's Gardens|^Egyptian Pyramids|^Colossus of Rhodes
 No hystorical event can compare with The Ancient Master KHALAL's birth.\r But a few like the end of The War of Vietnam and the introduction of\r Floppy Disks are also famous.  When did they happened?
^A> 1972|^B> 1973|^C> 1974|^D> 1975
 The art of battling has never been organized like it is in the ARENA.\r However, this art is no new.  A country known as U.S.A. went thru a war\r for indepence that ended in the year:
^A> 1783|^B> 1775|^C> 1774|^D> 1789
 Long ago, there was something known as SEAS.  Many were nothing but trickles\r of water.  Others were huge.  Can you tell me which was the largest?
^Philipine Sea|^Coral Sea|^Mediterranean Sea|^Gulf of Mexico
 Before oceans and rivers dried up, people liked to go on extrange water\r activities such as fishing.  Amongst rivers, some where very large.\r In fact can you tell me which was the largest?
^Amazon|^Mississippi|^Nile|^Chang Jiang
 This is gonna be quick and simple.\r What do the names Miranda, Ariel, Umbriel, Titania, and Oberon have\r in common?
^Used in Disney movies|^Rare Minerals|^Persian Letters|^Moons of Uranus
 Of the names I will give you, there is one that is not related to the others.\r Can you tell me which one doesn't belong?
^Aconcagua|^Titicaca|^Huron|^Maracaibo
 Before the end of civilization, scientists got into the habit of naming\r everything they could with weird names known as scientific names\r What was called a GIANT RANUNCULUS?
^Rat|^Plant|^Bacteria from Peru|^Dinosaur
