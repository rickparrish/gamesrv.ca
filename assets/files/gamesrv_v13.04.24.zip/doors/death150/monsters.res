@LEVEL1
Thief;			1    	0    	0    	0    	0
Dark Night;		2    	0    	0    	0    	0
Dilbert;  		3    	0    	0    	0    	0
Mangy Dog;  		4    	0    	0    	0    	0
Insane Hermit; 		5    	0    	0    	0    	0
@LEVEL2
Giant Snake;  		6    	0	0    	1    	0
Cyclops;  		6    	0    	0    	2    	0
Bloody Pirate;		7    	1    	0    	3    	0
RAL the Warrior;  	8    	2    	0    	3    	1
Lizardtoid; 		8    	3    	0    	3    	2
@LEVEL3
Snake-Dragon;    	8    	4	0    	4	3
Skeletal Dog;  		9    	5    	0    	5    	4
Feral Cat;    		10   	6    	1    	6    	5
Fetid Beast;    	11   	7    	2    	7    	5
CAOS the IronMaster;	12   	7    	3    	7   	5
@LEVEL4
Shadow Un-Caster;   	13   	8    	4    	8    	6
The Unchosen One;   	14   	9    	5    	9    	6
Gorr;    		15   	9    	6    	10   	7
Insectoid;    		16   	10   	7    	10   	7
Ske-Tar, the Beast;	17   	11   	7    	10   	8
@LEVEL5
Skeleton Warrior;   	18	12	8    	11   	8
Stone Giant;		19	13	9    	12   	9
Fire Giant;		19	14	9    	13   	10
Wandering Skull;	19	15	10   	14   	11
Devil's Shadow;		20	16	10   	15   	12
@LEVEL6
Evil Shadow;		21	17	11   	16   	13
Gargoyle;    		22	18	12	17	14
Mourning Specter;   	23	19	12	18	15
RAI, Bearer of Pain;	24	20	13	19	16
Low-Levels Overlord;	25	21	13	20	17
@LEVEL7
Purgatory's keeper;	26	22	14   	21	18
Adolf Hitler;    	27	23	14	22	19
Satanic Black Dog;  	28	24	15	23	20
RAI, Maker of Blood;	29	25	15	24	21
Genghis Khan;		30	26	16	25	22
@LEVEL8
Water Elemental;	31	27	17	26	23
Air Elemental;   	32	28	18	27	24
Earth Elemental;    	33	29	19	28	25
Fire Elemental;     	34	30	20	29	26
Elementals Overlord;	35	31	21	30	27
@LEVEL9
Nabuconodozor;		36	32	22	31	28
Tyr the Ancient One;	37	33	23	32	29
Underground Serpent;	38	34	24	33	30
Venomous Gargoyle;	39	35	25	34	31
Invisible Skull;	40	36	26	35	32
@LEVEL10
Black Demon;		41	37	27	36	33
Red Demon;		42	38	28	37	34
Scarlet Demon;		43	39	29	38	35
Two-headed Demon;	44	40	30	39	36
Low-Demons Overlord;	45	41	31	40	37
@LEVEL11
The Pale Rider;		46	42	32	41	38
Nostradamus;		47	43	33	42	39
Hermod, Son of Odin;	48	44	34	43	40
Aegir, god of Sea;	49	45	35	44	41
Mars, god of War;	50	46	36	45	42
@LEVEL12
Vulcan, god of Fire;	51	47	37	46	43
Logi, Fire god;		53	49	38	47	44
The Dragon Maker;	55	50	39	48	45
Oceanus, The Titan;	57	52	40	49	46
@LEVEL13
The Maker of Dreams;	59	53	44	49	47
The Maker of Blood;	62	56	48	49	48
The Maker of Death;	68	59	52	49	49
Satanic Pet Dragon;	72	62	56	49	49
The Number of Beast;	75	65	60	49	49
@LEVEL14
Shade of Evil;		76	66	61	49	50
Night Stalker;		77	67	62	49	50
The ruler of flesh;	78	68	63	49	50
The Mind Master;	79	69	64	49	50
The Dream Weaver;	80	70	65	49	50
@LEVEL15
The Heart Eater;	82	72	66	49	50
Nighmare Essence;	84	74	68	49	50
Your Last Hope;		86	76	70	49	50
Grimmer's Touch;	88	78	72	49	50
The Beast Maker;	90	80	74	49	50	
@LEVEL16
Gargoyles Overlord; 	92	82	75	50	50
The Fourth Rider;	94	84	76	50	50
Belzebu;            	96	86	77	50	50
Mars, god of War;   	98   	88	78	50	50
The Anti-Christ;    	100  	90	80	50	50
@LEVEL17
Demonic Overruler;	100   	92	82	50	50
Satan Only Begotten;	101   	94	84	50	50
Satan;			102   	96	86	50	50
Luz-Bel the Devil;	103   	98	88	50	50
Zeus, Olympian Lord;	104   	100	90	50	50
@LEVEL18
DEATH MASTER KHALAL;	105  	105	105	50	50
