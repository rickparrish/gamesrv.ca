LOADING LANGUAGE. PLEASE WAIT.
The Death Master summons you to CHAT!\r\n
The Death Master has dropped dead or to DOS. Please wait.\r\n
~eALL ~fHAIL ~7TO ~c%s! ~7HELL'S ~fNEW ~eD~dE~cA~bT~aH ~eM~dA~cS~bT~aE~9R!~8
^Death Masters arena|^Healing Center|^Weapons and Armor Shop|^Messages, Pages, and Chat|^Level Master|^Vault|m^Utation center|^Challenges|^Pub|^Tips [Read!]|^Graveyard|^Your extended Info|^Suicide!|e^Xit this inferno
~eSYSTEM MESSAGE:\n\n
~6Carrier ~edropped~6 while fighting.  Something bad happened to you...\n
No Log Available
!
!
!
!
!
!
!
!
!
!
!
!
!
!
!
!
!
!26
YOUR TIME IN THE GAME IS OVER.  TRY AGAIN LATER.
Profession:
Gold Pcs:
Your
Yes
not
yYnN
yes
Not
Would you like to use an ALIAS while playing the game?
PLEASE ENTER A LONGER ALIAS
PLEASE NO SPACES AT THE BEGINNING
Enter an alias:
NO ALIAS.  BBS NAME WIL BE USED!
** AN ERROR HAS OCURRED **
Please enter your real name [not a handle]
PLEASE WAIT: Needed file in use by another NODE.
PRESS A KEY QUICK OR I WILL DISCONECT YOU!
Please come back when you are awake!
3 or fewer minutes remain.  Return to BBS quick!
HPoints:
of
NAME:
Level:
Strength:
Exp:
Weapon 1:
Weapon 2:
Weapon 3:
Shield  :
Armor   :
Luck    :
Defense :
Attack  :
PwrKills:
You cry for mercy to a superior foe!
However, your cry is heard by mercyless ears!
%s has no soul but would let you go for %s coins.
Do you give the %s coins?
Shamefully, you pay your way out of certain death!
You refuse the shame of paying and fight on!
   You must be real lonely!  Get a life, looser!
   RAT!! That's impossible!
 ~2Start your message for ~e%s. ~2[~a10 Lines MAX~2]\r Press ~fENTER~2 on blank or 10th line to finish. ~fESC~2 to abort.
Quit? [Message won't be saved]
Done!
~fE-MAIL MESSAGE FROM: ~e%s~2\n\n
~5In pure love, ~f%s ~5transfered ~f%s coins ~5to your bank account!\nYou just gotta love folks like that!\n
~fSTATEMENT OF BANK ACCOUNT:\n\n
What killing method will you be training for?
^Decapitation|^Spine rupture|^Limb amputation|^Gut distortion
Decapitator
Vertebraker
Amputator
Gut Distorter
  You use your\r  tremendous skill\r  and ability to\r  effortlessly kill\r  %s!
These are your current attributes:
Do you want to re-roll your attributes?
 The road to fame is paved with many dead bodies...\r You only wish yours isn't one!
 You grip your weapon firmly, with confidence.\r As if your life depended on it...
 A myst from the North brings upon you the stench of death...\r Possible yours!
 YOU TREMBLE WITH FEAR AS YOU FACE:
^Attack|^Beg for mercy|^Take 4 wacks|^Lethal move [%d]
Your HitPoints:
  You received a bloody shot for
  Semi-conscious, you notice you have been hit for
  Blood gushes out of your forehead as you were hit for
  Your blinding speed proves useful as you are able to dock the shot!
  You fall to the ground but your quick reflexes spare you from injury!
  Your opponent can not believe it, as the shot is deflected by you!
  You lift your weapon up and crush the beast for
  You pierce thru your foe's wideopen torax causing
  You look in ecstasy as you inflict on your foe
  You bang your self on the head for missing this shot...
  Amazinly, you miss your foe's head by just a hair...
  You loose grip of your weapons and miss your foe completely!
points of damage!
Enter=
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 @%c[$%s] @%cItem number to purchase [@%cENTER=@%ccontinue, @%c0=@%cQuit@%c] @%c
HELL'S MENU
YOU CAN'T AFFORD THAT!!
SORRY,  YOU HAVE USED UP YOUR TIME FOR THIS SESSION
You don't have enough arms for that!
You were completely healed for a fee of %s gold pieces.
For lack of MONEY, only %d HITPOINTS were healed.
You are in need of no healing!  Don't waste your money!
You Killed %s!
You Are Tired.  Try Again Tomorrow!
YOU HAVE DIED!
You are in the Armory from hell.\r   What do you like to do?
^Buy New Weapons|^Sell Your Weapon|e^Xit this rat-hole
^X> Exit this joint|
Transact with ^Weapons|Transact with ^Armors|Transact with ^Shields|e^Xit the shop
Sell your %s for %s?
^Buy New Armor|^Sell Your Armor|e^Xit this nightmare
You have to sell your current armor first!
^Buy New SHIELD|^Sell Your SHIELD|e^Xit this joint
You have to sell your current SHIELD first!
~3Mutant stats: ~b%d Arms
Fights Left:
Fallen Masters present you with a gift of %s coins!
A Demon approaches you and asks for your weapon.  Give it?
 ~7The dark figure takes your ~f%s ~7and brakes it in half!
 ~7However, he replaces it with a more powerful ~c%s!
  Fool!  The dark figure screams as he takes\r  your weapon and breaks it in half!
A charm is spewed forth from your victim's mouth.  Your LUCK is raised!
 The grounds opens up in half and from within the guts of hell,\r up comes the most demonic DEATH MASTER you ever have seen\r\r YOU KNOW YOU ARE NO MATCH FOR SUCH A BEAST!
The evil 4-armed DEATH MASTER demands ALL your money.  Give it?
 You have shown great courage!\r The hideous beast morphes into a beautiful deidity and blesses you!\r\r YOU FEEL ELATED!
 Amazingly, the beast lets you leave taking no money from you.\r But there is an extrange sorrow in its eyes...
 You rest proud after killing your foe.  But, while the old masters\r remove the dead body, an old man approaches you and probing you\r with his stick proceeds to say:
 My child, I will give you MANY INCREDIBLE BLESSINGS if you can\r answer me one question... \r\r Do you take a shot at the question?
\r\r~aEXCELLENT!\rMost RATS would have missed that!\r\r~cThis is the reward for your knowledge:\r\r
\r\r ~2As hard to believe as it may sound to you,\r ~fTHAT WAS NOT THE RIGHT ANSWER!\r\r ~2But don't give up. I will be seeing you again soon... ~cRAT!
went up by
You get %d extra Arena fight(s) today!
 An ancient DEATH MASTER from the past rises up from within hell's gut\r and salutes you after a fight well fought.  Then, he says:
 "Although you have lots to learn, your skill and fighting style have\r brought me here.  You have pleased many fallen MASTERS with today's\r
 fight and as a reward, I will replace your armors and shield for better\r ones.  However, you must tell me the name of your current armor."
 So, What's the name of your ARMOR? :
 ~e-~f=~7[~aP~2ress a ke~ay~7]~f=~e-
Unreal!  You don't even know the name of your ARMOR!
Rolled attributes range from %d to %d points.
Duplicate handle. CHOOSE a new one.
User joining the game
User leaving the game
  You inflict %d points of damage on %s, but it\r  is not enough to kill the beast.\r  You have wasted your lethal move!
  You try to inflict tremendous damage on %s but you\r  miss your oponent and VALUABLE lethal experience points!
You don't have any LETHAL moves left!!
   For JACKPOT of %s coins, guess the LETTER I have in mind!
-=-=-=-=-=-=  C  O  N  G  R  A  T  U  L  A  T  I  O  N  S  !  =-=-=-=-=-=-=-=-\r\r\r-=-=-=-=-=-=-=  The BBS Jackpot of %s coins is yours!!  =-=-=-=-=-=-=-=-=-
Sorry. I was thinking the [`bright white`%c`bright red`]!  7,500 coins added to the BBS Jackpot.
 Your enemy does not want to fight!\r He offers you the money carried if you let\r him go free unharmed.\r\r Do you let him go?
 As promised, he gives you all the money he carried in exchance for\r his life.  The arena score-keeper rewards you with some EXP POINTS too!
 A sinister figure approaches you on your way to the Death Masters Arena\r and asks if you would like to buy some steroids before going\r for your next challenge.
 He'd sell them steroids for %s coins.  Buy?
 You pay for the steroids and take'em inmediately.\r The effects on you are incredible!  You feel GOOOOOD!
 I am sorry... You don't have enough money for my services!!
 You refuse his services and he just disappears down the road...
 A couple of drunk guys approach you and without saying a word\r proceed to beat you up!\r They leave after making sure you are bleeding your guts out!
 Hold your horses for just a second.\r MAINTENANCE MODE ENGAGED...
C H A L L E N G E
MESSAGING SYSTEM
MONEY TRANSFERS
Joined The Game!
Left The Game!
~9   Which one? [~f0=~eQuit~9/~fENTER~e=Next Page~9] Enter a number:~d
^Write a message|^Page another player|Public ^Chat|^Read your email|^Today's news|^Yesterday's news|Post ^Announcement|r^Ead Announcements|e^Xit
PICK A USER TO PAGE
Enter a short message for %s:
Press [ESC]ape to continue
Page aborted. %s is not online!
   TOP SCREEN: public chat           BOTTOM SCREEN:
   Commands:  /HELP      /COLOR ##     /EXIT or [ESC] at beg of line
/HELP
/COLOR%c
JOINING A SECT
/EXIT
���� LEFT PUBLIC CHAT ۲��
ONLINE
IN CHAT
ALIVE
DEAD
@%c-=-=-=-=-=-=@%c  C  O  N  G  R  A  T  U  L  A  T  I  O  N  S  !  @%c=-=-=-=-=-=-=-=-\r\r\r-=-=-=-=-=-=-=  @%cYou have become an ancient DEATH MASTER!  @%c=-=-=-=-=-=-=-=-=-=-=
  You enter this place built to host demons and death masters of the past.\r
  You have been told not to look the Level Master in the eye for you could\r  die instantly...  painfully.  You cover your face and enter...
 What would you like to do?
^Increase a level|^Demote enemies spell|^Blind enemies spell|e^Xit this infernal place
 The ground opens up with a tremor as the Level Master spits fire from\r his mouth and throws you out of his hut.\r\r
 ~c"Leave miserable rat! I have no time to waste with rats like you!"\r\r ~2You need ~f%s~2 more points before the Master will talk to you.\r
 Many rats have come my way begging to mutate so they can become more\r powerful killers and further narrow the gap between them and the\r ancient DEATH MASTERS\r\r
 And you have got to be the stinkiest and biggest RAT of all!!\r Get the hell out of here you sorry excuse for a DEATH MASTER  wanna-be!\r\r
 However, you are worthy of ancient Death Masters recognition.\r Your battles are known all throughout the land and your skill is admired\r by friends and enemies alike...\r\r
 Close your eyes and die...  and rise again A MUTANT!!\r\r
 You must have the right combination of LETHAL KILLS and LEVEL before\r I can do anything for you.\r\r
D E M O T I N G    E N E M I E S !
 ~2A fee of ~f%s~2 coins is associated with this most evil of all services.\r However, there are no guarantees about the effectivenes of the spell.\r\r There is at least a ~c20%%~2 chance the spell will succeed, ~ePLUS~2 a secret factor.\r
 If you know the secret of the Masters, ~aTHE SCORE OF YOUR ENEMY~2 will reveal\r to you what this factor is.  However, no mortal ever has known how to\r descipher this most guarded secret...\r\r
 Only the fallen Master ~f%s~2 knew about it, but he is long dead.\r\r A legend says you have to look at the last number in the score of your\r enemy, but the meaning of this most guarded number is unknown...\r\r~2
 The Level Master's evil spell has FAILED!
 So... go for it?
Calculating demotion at %d%%
%s DEMOTED %d points!\r
\r\rExperience for %s was demoted to %s!\r\r
%s has been demoted to level %d!!
\r\r What the hell?  I can demote you for free if you realy want it!
\r\r I am sorry.  This sneaky move can only be performed when your enemy\r is OFFLINE.
ENEMY'S LEVEL IS TOO LOW FOR DEMOTION
~f%s ~cwas demoted to level %d by %s!~8
~cTODAY'S INQUISITOR READS:~8
 ~aC~2ontinue?
~e%s ~3advanced a level in the race to escape hell!~8
~bFor the first time, the gates of hell opened for ~f%s!~8
~aAn attempt to demote ~f%s ~afailed miserably!~8
~9Like a rat, ~f%s~9 paid %s coins to escape certain death!~8
~4Shamefully, ~f%s ~4died against %s!~8
~cJACKPOT OF %s COINS WAS WON BY ~f%s!~8
~b%s~2 entered the game.~8
 However, you have already achieved the greatest mutant level possible!\r Please leave, there is nothing else I can do for you.\r
Save messages?
 You have no private e-mail messages.
New mail received.  Check your mail-box.
Your have chosen wisely.  Your name bears POWER!
KILLS:
^Deposit|^Withdrawal|^Transfer to friend|e^Xit this cheap joint
NO SECTS FOUND.  Start one!
Not enough memory to continue!
File not found!
File Open Failed!
File Write Failed!
File Read Failed!
Ask your SysOp to read ERROR.LOG and report it to the author.
 According to our books, you have `bright white`%s`green` gold coins stored.\r How much do you want to withdraw? [`bright white`1= `bright yellow`ALL`green`]
 I understand your needs are great, but we are not running a charity here!\r You do not have that much in our vaults!
 Excellent choice!  Please come again soon!
 You have way too much money in our vaults already!\r What are you doing?  Selling drugs or something?
 According to our records, you have `bright white`%s`green` gold pieces.\r How many would you like to deposit? [`bright white`Enter= `bright yellow`all`green`]
 Sure, sure.  And Mary Poppins never had anything going with Bert.\r What do you take me for?  A fool?  You don't have that much\r money! Go away vicious, rotten, little RAT!
 May Hell protect you!  We were not able to accomodate all the money you\r have in our vault.  It sure is a good problem to have! is it not?
~9   How much to transfer to ~a%s~9? [~eMax~f=%s~9/~eENTER~f=Quit~9]~d
\r\r~2   You seem confused... You don't have ~f%s ~2coins in the bank!\r   Go back to the ~cRATS ~2you belong to, and be back when your head clears.
\r\r~f   Done! ~2A letter of notification has been sent to ~f%s~2\r   regarding your generous transaction.
\r\r~c   Transaction aborted.
 ANSI graphics is necessary to play this game.\r I was unable to determine your ANSI graphics setting.\r Type [Y] if you have ANSI enabled, or anything else to exit.
^Order a cold one|^Change your name|^Take a leak|^Get room for the night|^View enemy stats|^Sabotage bank accounts|e^Xit this crap!
~eSpit and vomit cover the floor and body of drunk\rpatrons who had one too many.  Yet, this is the\ronly place where you can find needed rest...
\r\r Ahhh... Either you are not happy with the name your parents gave you\r or you have made too many enemies behind the closed doors of the DEATH\r MASTERS' Arena.  It'll cost you ~f%s coins~2 to change your name.
\r So, go for it?
\r\r~a Done!  Thanks for your money!
~2 Only true Masters stop for a leak!
~2 Power-bearing names is only a myth... ~aDon't I know that!
~e Just who in the hell left the toilet wet!!!
~2 This game is sick!  If you don't have money it calls you Mary Poppins!
~3 I kick anybody's butt.  Here in the bathroom and at the Arena!
~4 Man I keep dying!
~2 How do you guys put colors in the messages?
~2 Hello?  I am new rat hehehe :]
~2 Let's get some teams going!! ~dAnd kick some butt!
~2 They should pay ~fME ~2to pee in this filthy place!
~f You stop to take a most needed leak and can't avoid reading all this crap:
\r\r You could scribble more crap on the walls with your weapon...
\r Enter some crap then!\r
\r You take the seat closest to the bathroom... With the kind of drinks served\r here it is probably the wisest thing to do.\r Buck, the three-armed bartender greets you and demands to know what your\r poison will be...
^Order a drink|^Invite Buck to a cold one
^Winnies Brew    $100|^Tequila's Worm  $200|d^Ragon's Ale    $300|^Centennial Malt $400|^Devil's Lager   $500|^Master's Liquor $600|^X> Never mind
\r\r You force the potion down your throat.  Amazingly, you feel VERY good!\r\r
\r\r By now, the drinks taste ~fvery good!\r ~2You get your bottle and get up from your sit by the restroom.\r You get down on the dance floor ~dand start stripping off your clothes!\r ~2Suddenly, you feel the effect of excess alcohol in your body\r
 and collapse on the floor.\r\r A couple of bar patrons ~cvomit on you on their way out ~2and that\r seems not to bother you anymore!\r ~2Slowly, you close your eyes and ~ffall asleep.
\r\r ~2Ahhhh... That hit the spot!  Thanks ~f%s!~2\r\r
 Listen %s, I'll let you in on a secret:\r It has been long rumored that names bare great power.  I got news for\r you, It is not just a rumor! ~cIt's true!\r\r ~2For only ~f%s~2 coins I can tell you one of these names...\r
\r\r ~fOne of the ~cDEATH MASTERS~f of the past was called ~e%s.\r\r
KILL YOUR SELF?
This will erase your character permanently.  Do it?
PAGAN!  You already belong to a Sect!
Enter the name of your SECT:
~cTEMPLE NOTIFICATION:\n~7%s is no longer a member of our sect.\n~2
~cTEMPLE NOTIFICATION:\n~7%s has joined our sect!\n~2
That Sect is full.  Join another one
FOOL!  You don't belong to a SECT!
^Offer money to %s|Offer your life in ^Sacrifice|Request ^Destruction of another sect|^View sect rankings|e^Xit this unholy place
You don't belong to a SECT!  You must join one first!
SECT DESTRUCTION REQUEST
~9   [~f0=~eQuit~9/~fENTER~e=Next Page~9]
S E C T   R A N K I N G S
TRY LATER: %s is being attacked by someone else!
LET'S FIGHT! [You'll be healed if need it]  GO?
Press ANY KEY to continue
\r\r ~f** BATTLE WAS DECLINED! **
\r\r ~e** BATTLE HAS BEEN ACCEPTED! **
 Awaiting response. %d seconds left.
LIVE BATTLE
\r\r ~bTIMED OUT.  ~bTRY AGAIN LATER.
 Lucky RAT!  Your challenger is no longer waiting for you!
File Create Failed!
File Erase Failed!
^Attack|^Yell to %s|^Power move [%d] ~TimeOut=`DEATH
 ~f%s, DID NOT RESPOND!  Press a key to END this FIGHT!
You died shamefully, the Arena is closed for you until tomorrow.
\r  ~aYOU ARE WAY TOO TIRED FOR THAT.  TRY AGAIN TOMORROW.
\r  ~a%s ~fis currently LOCKED OUT for shamefully dying today!\r\r
\r\r~a"You seem ready to study higher mystic mysteries" ~2The master says\ras he unveils his face to expose a horrid fallen master of the past!\r\r~cAmazingly, you do not die!  Rather, you feel better than before!\r\r
~c%s was killed by ~4%s!~8
~fIN A RARE MATCH, ~c%s~f AND ~c%s ~fKILLED EACH OTHER!~8
~cBATTLE STATUS:\n\n
~4You were attacked by %s but you were victorious!\n
~4You were attacked by %s and died like a RAT!\n
No more equipment!  Awarding %s coins.
~5Dividends of ~d$%s~5 were posted to your account.\n
Go back to BBS?
JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC
Timeout in %d seconds.
��� ENTERED PUBLIC CHAT ���
~f  %s ~bis staying at The Pub and can't be disturbed!\r  However, Buck'll let you in for ~f%s~b coins. Pay?
  Buck, while still tending to the rather smelly bar-customers, explains to\r  you that staying at this unsanitary place for the night is the best thing\r  you can do in a land where dying and killing is the way of living.\r\r
  Rooms at this reputable stablishment don't offer any protection against\r  those wishing to kill you.  However, they must first bribe Buck with a\r  good chunk of money or else they won't get to your room.\r
  It'll cost you %s coins to get a room.  Do it?
\r\r You pay the room and retire for the night, only hoping to able to\r wake up in one piece...
  Your enemy uses\r  a move you haven't\r  seen before, and\r  suddenly, you lay\r  lifeless on the ground!
  A power move from your enemy hits you for %d points!
Delay
@%cOn this glorious\r WEEK, @%c%s\r @%ckilled @%cKHALAL, @%cThe\r Ancient Death Master,\r and became the new\r @%cDEATH MASTER!
\r\r\r @%cThis game is full!\r\r @%cTell your SysOp about it and ask him/her\r to start a new one ;)
%s seems a bit too DEAD!
Nobody has ever escaped hell.
~a%s ~2[~f%s~2] Escaped hell on ~c%02d/%02d/%d\n
\n\n~c         THE FOLLOWING PLAYERS HONOR THE DEATH MASTERS GRAVEYARD\n\n
is currently
You stole %ld EXP and %s coins from %s!
You LOST %ld EXP pts & %s coins to %s
~dBBS Jackpot raised to %s coins!~8
~f%s ~ecommited suicide. WHAT A WEENIE!~8
Mismatch! %s is too weak for you!
Heap Corrupted.
VIEW ENEMY STATUS
 You approach buck and offer him money in exchange of information on one\r of your enemies.  He continues to clean the crap-filled tables as he\r looks at you and says:\r\r
 "Very well, tell me who you want information on and I'll see what I can do\r about it... However, I don't run a charity house so it will cost you\r money.  Go ahead and tell me first who your victim will be..."\r
 Information on %s will cost you %s coins.\r Pay up?
In Vault:
 ~2Yes, the rumors you heard are true.  I can hire some folks to go to\r ~e%s's~2 bank and destroy up to ~a20%~2 of the gold in the Vaults.\r
 ~2In return, you must give me ~fONE~2 of your ~fchallenges~2 and ~f%s ~2coins.\r
 Pay attention as I want your ~cCHALLENGES~2 not your normal turns.\r
 YOU DON'T HAVE ENOUGH CHALLENGES LEFT TO PAY FOR IT!
~e%s ~fcoins (~a%d%%~f) destroyed from ~e%s's~f vault account!~8
S A B O T A G E
Challenges:
 What a waste! %s is broke!
~d%s ~5coins have been ~ddestroyed~5 from your vault account!\r
 You look in awe at\r %s for a\r last time before\r you close your eyes\r and DIE!
 I am sorry but I can't cast demotion more than twice a day.
 %s's Demon's Ring desintegrates in a tremendous explotion\r as the Demon's protection fights off your Demotion attempts!
 As the ring's Demon collapses under the Level Master's spell, you look\r at your enemy and smile...\r Then, the Level Master continues with the demotion...\r
 The blinding explotion interrupts the Level Master's demotion Ritual!\r %s was saved by the ring, which has been destroyed!\r
 Just as you approach the entrance to the Arena, a black demon raises up\r from the ground and asks if you would like to buy its ring.\r\r The demon's ring has the property to summon a Black Anti-Demotion\r
 Demon to come and fence off demotions targeted for you.\r\r Although the Level Master's magic is stronger than the Demon's, after it\r has been stablished that you WILL be demoted, the Black Demon will fight\r
 with the magic of the Level Master and give you a @%c60%%@%c chance of keeping\r your level... for only @%c%s @%cgold coins.\r\r
 However, the magic of the Level Master is stronger and the demon dies!
~fLEVEL MASTER REPORT:\n\n
~aYou were demoted by ~e%s!\n
~aEnter a PUBLIC ANNOUNCEMENT.~2 [~a5 Lines MAX~2]\rPress ~fENTER~2 on blank or last line to finish. ~fESC~2 to cancel
~f PUBLIC ANNOUNCEMENT BY: ~e%s~2\n\n~3
LAST LEVEL REACHED - THIS BATTLE IS FOR ALL THE MARBLES!
~7A demon died after protecting ~e%s~7 against a demotion!~8
~6%s ~eFAILED AN ATTEMPT TO ESCAPE HELL!~8
How about getting healed first?
A/D Ring:
  Sorry.  %s was already killed once today.
  Easy! %s is already behind you by a long shot!
Mystic powers within your name make magic happen...
  ~fNote that we charge a fee of ~e%s~f coins for this transaction.
  ~fIf you accept, the total transfer after our fee is ~a%s ~fcoins.
You can't start out with a power name!  Change it later.
 ~3Suddenly, as you prepare to enter the Arena, you find your self engulfed\r in a warm blue light.  ~b"My child"~3 a voice rumbles from within, ~b"I commend\r you for not having chosen the evil ways.  Many Death Masters often change
 their names in exchange for ~fcontinuos~b rewards.  Although ~fPower Names\r ~bare real and very powerful, I will summon my mystic powers to help you as\r much as I can..."
THE BLOOD OF FALLEN ENEMIES DECAYS YOUR WEAPONS!
TO ESCAPE HELL, YOU MUST REACH AND DEFEAT THE MONSTER IN LEVEL %d.
Hell's Pub Menu
~d%s ~5was seen ~dNAKED~5 and ~dVOMITED ON ~5at the pub!~8
~7Undried blood on ~d%s's ~7weapons caused their decay!~8
purchased!
You can't see well...  You have been BLINDED!
[- BL�ND�D -]
CASTING  BLINDNESS
 ~9Here is something very evil:  ~fThe Blindness Spell~9.  A blinded foe will NOT\r be able to identify the name of anybody.  Wether challenging, transfering\r money or sending a message, ~bblind players won't know who they are interacting\r
 with~9.  Use this spell with caution:  ~fthere is no cure for it and it lasts for\r two whole days~9.  If you are interested in something this evil, choose \r who your target is first, so I can tell you what the cost for it is...\r
 Before we go on, I must tell you that you have a generous ~c1 in 4 ~9chances of\r success with this spell... And remember, if successful, for the next two days,\r your enemy won't be able to identify you or anyone else!!
 ~7A blindness spell against ~c%s~7 will cost you ~f%s~7 coins\r and ~fONE~7 of your challenges.  Do it anyway?
 ~d%s ~7Has been blinded for 2 days!~8
 The hideous level monster uncovers his face and enters a mistyc portal.\r From whitin, he emerges with your foe as you avoid the Master's lethal gaze.\r In a sudden move, he looks at %s in the eye and
 Don't waste your money.  %s is currently blind!
~7A blindness spell against ~d%s~7 failed!~8
