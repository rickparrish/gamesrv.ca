There can be AT MOST NINE POWER NAMES and they SHOULD NOT BE LONGER than 10
characters, also they ALWAYS start at the third line of this file!
