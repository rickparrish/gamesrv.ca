 - Type 'catalog' at the DOS prompt for RPG2100 DoorWare list of programs -

============================================================================
                   DEATH MASTERS v1.50 REGISTRATION FORM
============================================================================

 YOUR NAME:  _______________________________________________________________

 BBS NAME:   _______________________________________________________________
               ( Key code is Case-sensitive.  Please capitalize properly! )

 POSTAL ADDRESS: ___________________________________________________________

                 ___________________________________________________________

                 ___________________________________________________________
 
 HOW DID YOU GET A COPY OF THE GAME: _______________________________________

 BBS PHONE NUMBER: ___________________________ SOFTWARE: ___________________
 
============================================================================
 HOW DO YOU WANT TO RECEIVE YOUR REGISTRATION KEYS? 
============================================================================

 INTERNET EMAIL     [  ] => ADDRESS_________________________________________
 CONVENTIONAL MAIL  [  ]
 *UPLOAD TO MY BBS  [  ]   (You must pre setup an account.  SEE BELOW)
                        
 | FOR UPLOAD TO BBS ONLY:        
 |  Additional fee of $3.00 for US & Canada addresses.  $6.00 to all others.
 |  What is the author's LOG IN name________________________________________
 |  What is the author's PASSWORD   ________________________________________
 |
 |   I will make every reasonable attempt to call your BBS and upload the
 |   registration keys; BUT, if due to faulty connections, OR if I cannot
 |   connect after trying several times a day for a period of THREE days, I
 |   will send your keys by conventional mail.  THERE WILL BE NO REFUNDS!
 |__ (I hope this is fair. If you have a better idea, please let me know!)

=============================================================================
 PLEASE SEND $20.00 PLUS ANY ADDITIONAL FEES (e.g. CA TAX, BBS UPLOAD, etc)
=============================================================================

          SEND CHECK OR  >>>     CARLOS R. GARCIA
          MONEY ORDER IN >>>     259 N. CAPITOL AV. #187
          U.S. FUNDS TO  >>>     SAN JOSE, CA 95127-2390
 
+--OFFICE USE ONLY-------------------------------------------------+--------+
|                                                                  |        |
| Rcvd: _________  Key: ___________________  S/N: _________________|        |
+------------------------------------------------------------------+--------+
| D1 __:__|__:__|__:__     D2 __:__|__:__|__:__     D3 __:__|__:__|__:__    |
+---------------------------------------------------------------------------+