Nothing
Wicker Shield
Small Leather Shield
Round Leather Shield
Oval Leather Shield
Snake-skin Shield
Large Rectangular Shield
Wooden Round Shield
Large Wooden Shield
Spiked Shield
Iron Spiked Shield
Medieval Shield
Black Onix Shield
Black Forest Wood Shield
Touch of Fear
Aztec Feather
Blood of the Masters
Demonic Laments
Helmet of Protection
Ruby Shield
Volcano-ash Shield
Ancient Emerald Shield
Connan's Shield
Ring of Death
Reaper's Ring
Silent Occarina
Giant's Hand of Iron
Black Diamond Shield
Blood-Casted Shield
Shield of Fire
Osiris Protection
Nostradamus' Ring
Orbe of Protection
Ruby Orbe
Evil Force
Scream of Fear
Elemental's Cape
Ring of the Unchosen
Glove of Fright
Ancient Mayan Disc
Orb of the Old One
Gargoyle's Wing
Unholy Hand
Apollo's Oracle
Black Force
Orion Star
Jupiter's Shield
Evily Begotten Shield
Luz-Bel's Evil Love
Satan's Soul
Death Master's Shield
