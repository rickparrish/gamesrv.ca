Nothing
Loin Cloth
Heavy Cloak
Bone-reinforced Quilt
Leather Vest
Skirt of Tasses
Reinforced Leather
Leather Scale
Leather Breastplate
Iron-reinforced Quilt
Iron Scale
Armored Jacket
Chain Mail
Iron Mail
Conquistador's Armor
Mail Plate
Armored Scale
Coat Of Mail
Suit Of Mail
Plate Armor
Full Plate
Suit Of Plate
Ivory Plate
Cloak of Protection
Black Master's Armor
Ruby Pendant
Diamond Suit
Nosferatu's Force
Hipson's Ring
Daconta's Ring
Cursed Ruby
Mystic Charm
Fallen Master's Amulet
Ancient Onix
Evil Runes
Glass Orb
Necrosantum's Pendant
Alchemist's Orb
Sacred Ruby Plate
Iron-Diamond Quilt
Phoenix Ring
Moon Plate
Fire Armor
Mystic Armor
Magical Protection
Protection Spell
Rune of Invisibility
Egyptian Pyramid Powers
Supreme Evil Protection
Death Master's Cassock
Khalal's Armor
