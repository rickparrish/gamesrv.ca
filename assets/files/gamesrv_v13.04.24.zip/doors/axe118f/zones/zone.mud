# Zone file for Axe and Fang By Charles Marchant 1994

# mobs in Imps chat room # 1

M 0 1           Load BoneCrusher's Honor Guard

M 2 3           Load Chief
O 2 3           Load Chiefs Hat
E 6             Equip Chief with hat

#--------------------------------------------
# Town of Tooth
#--------------------------------------------

M 3 10          Load town guard
M 3 10          Load town guard

M 4 11          Load Gimp into Red Dragon Pub
O 4 11          Load Pint of Rum
G               Give Gimp Rum
M 5 11          Load Customer
M 5 11          Load Customer
M 6 12          Load Boxsum Bar Winch into commner's room

O 5 10          Load Dagger to Town Square

#---------------------------------------------------------------
# Back ally
#---------------------------------------------------------------

M 7 39          Load Mugger into back ally
O 5 39          Load dagger
E 16            Equip mugger dagger
M 7 39
O 5 39
E 16
M 8 37          Load Vagabond into Back ally
O 3 37          Load Short Sword
E 16            Equip Vagabond with short sword

#---------------------------------------------------------------
# Shops
#---------------------------------------------------------------

M 9 32          Load Garth into Genral Store
O 7 32          Load 3 torchs and give to Garth
G
O 7 32
G
O 7 32
G
O 23 32         Load 2 waterskins
G
O 23 32
G

M 10 34         Load Irongrip into blacksmith shop
O 8 34          Load and wield Massive Hammer
E 16
O 3 34          Load Short Sword
G
O 5 35          Load Dagger
G
O 6 34          Load Leather Vest
G
O 60 34         Load leather boots
G
O 61 34         load leather sleeves
G
O 62 34         load leather leggings
G
O 63 34         load small wooden shield
G
O 64 34         load leather skull cap
G

M 11 35         Load Shang Loo into Meat and Grain
O 9 35          Load bread
G
O 10 35         Load steak
G
O 11 35         Load mutton
G
O 12 35         Load pot pie
G

M 12 16         Load the healer in temple
O 13 16         Load some blue potions
G
O 13 16         Load some blue potions
G
O 13 16         Load some blue potions
G
O 13 16         Load some blue potions
G
O 13 16         Load some blue potions
G
O 13 16         Load some blue potions
G
O 13 16         Load some blue potions
G

M 13 41         Load Smug into magic shop
O 14 41         Load Slinder wand    -(magic missile)-
G
O 15 41         Load narraled stick  -( blindness )-
G
O 16 41         Load blue wand       -(lightning bolt)-
G
O 17 41         Load oak staff       -(heal)-
G

M 14 42         Load Racknor into alciemist shop
O 18 42         Load black potion ( sacntuary )
G
O 19 42         Load amber potion ( armor/bless/str )
G
O 20 42         Load green potion ( remove poison )
G
O 22 42         Load yellow potion ( strenght )
G
O 21 42         Load Gray potion   ( invis )
G

M 16 44         Load One Eye into Blackmarket

M 32 75         Load Sly Sue the Innkeeper

#-------- Old Warehouse -------------

M 15 43
M 15 43
M 15 43

#------- Guild Masters --------------
M 17 19         Load Magic User's Guild Master
M 18 18         Load Necromancer
M 19 22         Load Thief
M 20 21         Load Cleric
M 21 25         Load Monk
M 22 24         Load Assassin
M 23 27         Load Warrior
M 24 28         Load Knight
M 25 29         Load Barbarrian

#-----------------------------------------------------------------------
# End of Tooth  Rooms 10 to 44 by Charles Marchant
#-----------------------------------------------------------------------
# Graveyard Rooms 45 to 74 by Charles Marchant
#-----------------------------------------------------------------------

M 26 60           Load Walking Corpse
M 26 65           Load Walking Corpse
M 26 69           Load Walking Corpse
M 26 71           Load Walking Corpse
M 26 48           Load Walking Corpse
M 26 68           Load Walking Corpse

M 27 46           Load Giant maggot
M 27 47           Load Giant maggot
M 27 62           Load Giant maggot
M 27 67           Load Giant maggot
M 27 64           Load Giant maggot
M 27 74           Load Giant maggot


M 28 66           Load Skilliton
M 28 67           Load Skilliton
M 28 68           Load Skilliton

M 29 57           Load Stinger
M 29 53           Load Stinger

M 30 72           Load Goul

M 31 50           Load Zombie
M 31 61           Load Zombie
M 31 63           Load Zombie
M 31 65           Load Zombie
M 31 67           Load Zombie
M 31 69           Load Zombie

#------------------------------------------------------------------------
# End of Graveyard
#------------------------------------------------------------------------
# Goblin Mountain Range
#------------------------------------------------------------------------

M 34 80            Load fisherman
O 25 80            Load raft
G
O 25 80
G

M 33 79            Load Goblin Scout
O 24 79            Load rusted vest
E 5                Wear vest on body
O 3 79             Load Short Sword
E 16               Equip Goblin with short sword
O 26 79            Load Goblin Stronghold Key
G

M 33 81            Load Goblin Scout
O 24 81            Load rusted vest
E 5                Wear vest on body
O 3 81             Load Short Sword
E 16               Equip Goblin with short sword

#------------------------------------------------------------------------
# End of Goblin Mountain Range
#------------------------------------------------------------------------
# Crystal Lake, Meridon, Silver, Rapaly, North & South Meridon Rivers
#------------------------------------------------------------------------

M 35 93            Load white bass
M 35 106           Load white bass
M 35 99            Load white bass
M 35 108           Load white bass
M 35 114           Load white bass
M 35 118           Load white bass
M 35 122           Load white bass

M 36 96            Load black bass
M 36 99            Load black bass
M 36 107           Load black bass
M 36 109           Load black bass
M 36 116           Load black bass

M 37 97            Load Gar
M 37 112           Load Gar
M 37 120           Load Gar
M 37 108           Load Gar

M 38 99            Load Water Spider
M 38 106           Load Water Spider
M 38 115           Load Water Spider
M 38 128           Load Water Spider

#------------------------------------------------------------------------
# END of Crystal Lake, Meridon, Silver, Rapaly, North & South Meridon Rivers
#------------------------------------------------------------------------
# Goblin Stronghold
#------------------------------------------------------------------------

M 39 151            Load Goblin Guard
O 31 151            Load Scimitar
E 16                Wield Scimitar
M 39 151
O 31 151            Load Scimitar
E 16                Wield Scimitar
M 42 151            Load Small Warg

M 41 152            Load Goblin Sentry
O 27 152            Load Key
G
O 38 152            Load Breast plate
E 5                 Equip to body
O 30 152            Load Wicked Sabre
E 16                Wield Sabre
O 34 152            Load leggings
E 7                 Wear on legs
O 35 152            Load Arm bands
E 10                Wear on arms



M 40 171            Load Goblin Warrior
O 31 171            Load Scimitar
E 16                Wield Scimitar
M 40 171
O 31 171            Load Scimitar
E 16                Wield Scimitar
M 40 171

M 45 172            Load Goblin Captain
O 38 172            Load Breast plate
E 5                 Equip to body
O 30 172            Load Wicked Sabre
E 16                Wield Sabre
O 34 172            Load leggings
E 7                 Wear on legs
O 35 172            Load Arm bands
E 10                Wear on arms
O 37 172            Load Iron helmet
E 6                 Wear on head
O 36 172            Load heavy boots
E 8                 Wear on feet

M 43 154            Load Large Warg

M 40 156            Load Goblin Warrior
O 28 156            Load southern tower key
G
M 44 158            Load Goblin Slave
M 40 159            Load Goblin Warrior
M 44 162            Load Goblin Slave
M 40 167            Load Goblin Warrior
O 29 167            Load Armory key
G
M 40 170            Load Goblin Warrior
M 40 168            Load Goblin Warrior
M 40 165            Load Goblin Warrior
M 44 155            Load Goblin Slave
M 40 169            Load Goblin Warrior

#------------------------------------------------------------------------
# END of Goblin Stronghold
#------------------------------------------------------------------------
# Dunlan Forest and Troll Lair
#------------------------------------------------------------------------

M 50 137            Load rabbit
M 50 133            Load rabbit
M 50 138            Load rabbit
M 50 139            Load rabbit

M 49 132            Load Squerril
M 49 135            Load Squerril
M 49 144            Load Squerril
M 49 140            Load Squerril

M 51 138            Load Stag
M 51 133            Load Stag
M 51 141            Load Stag
M 51 146            Load Stag

M 48 149            Load Huge male troll in den
O 39 149            Load massive club
E 16                Equip troll
M 47 147            Load Female Troll
O 40 147            Load Troll Hide
E 5                 Wear on body
M 46 147            Load Baby Troll
O 41 147            Load Bone Ring
E 1                 Wear on right finger

#------------------------------------------------------------------------
# END Dunlan Forest and Troll lair
#------------------------------------------------------------------------
# Town of Culhaven
#------------------------------------------------------------------------

M 52 215            Load Barkeeper
M 53 225            Load Receptionist
M 54 228            Load Blacksmith
O 50 228            LOAD HAMMER
G
O 51 228            LOAD MACE
G
O 52 228            LOAD BATTLEAXE
G
M 55 217            Load Armorer
O 43 217            LOAD FULL SET OF DWARVEN ARMOR
G
O 44 217
G
O 45 217
G
O 46 217
G
O 47 217
G
O 48 217
G
O 49 217
G
M 56 218            Load baker
O 9 218             load bread
G
O 10 218            Load steak
G
O 11 218            Load mutton
G
O 12 218            Load pot pie
G
M 57 223            Load Grocer
O 7 223             Load 3 torchs and give to Garth
G
O 7 223
G
O 7 223
G
O 23 223            Load 2 waterskins
G
O 23 223
G
M 58 232            Load Sailor
M 59 208            Load guard into room
O 50 208
E 16
M 59 208
O 50 208
E 16
M 60 208            Load Captain of guard
O 43 208            LOAD FULL SET OF DWARVEN ARMOR
E 5
O 44 208
E 7
O 45 208
E 10
O 46 208
E 14
O 47 208
E 9
O 48 208
E 8
O 49 208             LOAD BATTLE AXE
E 6
O 52 208
E 16
M 59 209             LOAD GUARDS AND HAMMERS
O 50 208
E 16
M 59 209
O 50 208
E 16
M 59 230
O 50 208
E 16
M 59 230
O 50 208
E 16
M 59 224
O 50 208
E 16
M 59 221
O 50 208
E 16
M 61 220            Load some Citizens of Culhaven
M 61 216
M 61 210
M 61 214
M 61 229
M 61 231
M 62 222            Load Jeweller
M 12 227            Load healer
O 42 227            Load some clear potions
G
O 42 227            Load some clear potions
G
O 42 227            Load some clear potions
G
O 42 227            Load some clear potions
G
O 13 227            Load some blue potions
G
O 13 227            Load some blue potions
G
O 13 227            Load some blue potions
G
#------------------------------------------------------------------------
# END Town of Culhaven
#------------------------------------------------------------------------
# Trail from tooth to culhaven
#------------------------------------------------------------------------

M 64 86            Load Ranger
O 58 86            Load Brown Cloak
E 3
M 64 174           Load Ranger
O 58 174           Load Brown Cloak
E 3
M 64 186           Load Ranger
O 58 186           Load Brown Cloak
E 3
M 65 88            Load Merchant
O 59 88            Load carved box
G
M 65 176           Load Merchant
O 59 176           Load carved box
G
M 65 188           Load Merchant
O 59 188           Load carved box
G

#------------------------------------------------------------------------
# END trail from tooth to culhaven
#------------------------------------------------------------------------
# Dark Anar
#------------------------------------------------------------------------

M 63 254            Load Drow Scout
O 53 254            load dark chainmail vest
E 5
O 54 254            load dark leather boots
E 8
O 55 254            load dark longsword
E 16
O 56 254            load dark cloak
E 3
O 57 254            load glow worm
G

M 63 244            Load Drow Scout
O 53 244            load dark chainmail vest
E 5
O 54 244            load dark leather boots
E 8
O 55 244            load dark longsword
E 16
O 56 244            load dark cloak
E 3
O 57 244            load glow worm
G

M 63 245            Load Drow Scout
O 53 245            load dark chainmail vest
E 5
O 54 245            load dark leather boots
E 8
O 55 245            load dark longsword
E 16
O 56 245            load dark cloak
E 3
O 57 245            load glow worm
G

#------------------------------------------------------------------------
# END Dark Anar
#------------------------------------------------------------------------
# Underground River
#------------------------------------------------------------------------

M 67 291            Load Drow Warrior
O 53 291            load dark chainmail vest
E 5
O 54 291            load dark leather boots
E 8
O 55 291            load dark longsword
E 16
O 56 291            load dark cloak
E 3
O 57 291            load glow worm
G

O 65 299            Load Canoe onto beech

M 66 313            Load Drow Boatsman
O 65 313            Load canoe
G                   give him canoe so he can move
M 66 303            Load Drow Boatsman
O 65 303            Load canoe
G
M 66 310            Load Drow Boatsman
O 65 310            Load canoe
G
M 65 306            Load Drow Warrior
O 53 291            load dark chainmail vest
E 5
O 65 306            Load canoe
G
M 65 307            Load Drow Warrior
O 53 291            load dark chainmail vest
E 5
O 65 307            Load canoe
G
#------------------------------------------------------------------------
# END Underground River
#------------------------------------------------------------------------
# Shadow Lands
#------------------------------------------------------------------------

M 68 279             Load Dune Stalker
M 68 283

#------------------------------------------------------------------------
# END Shadow Lands
#------------------------------------------------------------------------
# Shadow Lands
#------------------------------------------------------------------------


$


