@echo off
echo �
echo This changes your keyboard rate to the fastest possible, makes moving
echo around in LORD2 faster.
echo �
mode con rate=32 delay = 1
echo All done!  Now type LOCAL to play.
echo �

