@ECHO OFF
CD DOORS\AMB4031
amblaunch.exe /n %1 /d ..\..\NODE%1 /socket %2
