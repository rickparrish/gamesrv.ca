﻿This is an alpha release of GameSrv v12.01.12

I do not recommend you run it in a production environment yet, as very little testing has taken place.
There's also a high degree of likelihood that configuration files/entries will change, which means users
may need to re-register in future versions.

That said, please abuse this as much as you can and let me know if you run into any problems.  For bug
reporting purposes, it would be best if you ran GameSrv with the DEBUG command-line parameter, which will
enable full exception reporting.  Then email a screenshot of the screen containing the error to rick@gamesrv.ca
along with a description of what you were doing to cause it, if possible

New in this version is Linux support!  Here's the steps I took to get it up and running on Ubuntu Server 11.04

Install pre-requisites:
sudo apt-get install build-essential dosemu libglib2.0-dev libmono-system-data2.0-cil mono-gmcs mono-runtime pkg-config

Extract the dosutils.tgz archive, which contains useful stuff for running doors in dosemu
cd dosutils
tar zxvf dosutils.tgz
cd ..

Compile pty-sharp, which is required to launch dosemu in a new pty from mono applications
tar zxvf pty-sharp-1.0.tar.gz
cd pty-sharp-1.0
./configure --prefix=/usr
make
sudo make install

Create a new user/group to run gamesrv as, since we don't want it always running as root
groupadd gamesrv
useradd -g gamesrv -s /usr/sbin/nologin gamesrv
chown -R gamesrv:gamesrv /gamesrv